#!/usr/bin/python
from __future__ import absolute_import, division, print_function

__metaclass__ = type

DOCUMENTATION = r"""
module: hello
short_description: Says hello
description: Returns a greeting.
author: dx
options: {}
"""

EXAMPLES = r"""
- name: Greet
  dxtest.tiny.hello:
"""

RETURN = r"""
msg:
  description: The greeting.
  returned: always
  type: str
"""

from ansible.module_utils.basic import AnsibleModule


def main():
    module = AnsibleModule(argument_spec={})
    module.exit_json(changed=False, msg="hello")


if __name__ == "__main__":
    main()
