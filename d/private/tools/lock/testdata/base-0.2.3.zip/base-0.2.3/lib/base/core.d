module base.core;
