module fsparse
use stdlib_kinds
end module fsparse
