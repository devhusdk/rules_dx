module stdlib_kinds
end module stdlib_kinds
