// swift-tools-version: 6.0
import PackageDescription

let package = Package(
    name: "mini",
    products: [.library(name: "Mini", targets: ["Mini"])],
    targets: [.target(name: "Mini")]
)
