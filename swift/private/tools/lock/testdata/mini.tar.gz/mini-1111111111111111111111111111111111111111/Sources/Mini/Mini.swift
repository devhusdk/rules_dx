public func mini() -> Int { 1 }
