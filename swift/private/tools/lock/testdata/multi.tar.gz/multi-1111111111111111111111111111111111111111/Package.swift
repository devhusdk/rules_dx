// swift-tools-version: 6.0
import PackageDescription

let package = Package(
    name: "multi",
    products: [
        .library(name: "Multi", targets: ["Wrap", "Extra"]),
    ],
    targets: [
        .target(name: "CCore", cSettings: [.headerSearchPath("private")]),
        .target(name: "Wrap", dependencies: ["CCore"], swiftSettings: [.define("WRAP")]),
        .target(name: "Extra"),
    ]
)
