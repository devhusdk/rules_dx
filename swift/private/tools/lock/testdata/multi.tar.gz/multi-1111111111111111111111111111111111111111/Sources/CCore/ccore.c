#include "ccore.h"
#include "inner.h"

int ccore_value(void) { return CCORE_VALUE; }
