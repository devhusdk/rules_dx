int ccore_value(void);
