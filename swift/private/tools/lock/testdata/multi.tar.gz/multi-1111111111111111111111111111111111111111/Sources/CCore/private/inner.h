#define CCORE_VALUE 7
