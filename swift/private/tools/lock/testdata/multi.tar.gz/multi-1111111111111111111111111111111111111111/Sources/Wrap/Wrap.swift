import CCore

public func wrapped() -> Int32 { ccore_value() }
